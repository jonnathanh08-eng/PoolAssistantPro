package com.example.poolassistant

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface
import kotlin.math.*

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 17, 25)
    private val panel = Color.rgb(20, 34, 46)
    private val cyan = Color.rgb(53, 211, 255)
    private val green = Color.rgb(75, 232, 157)
    private lateinit var diagram: TableView
    private lateinit var angleText: TextView
    private lateinit var powerText: TextView
    private lateinit var bounceText: TextView
    private var angle = 45
    private var power = 60
    private var bounces = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 16); setBackgroundColor(bg) }
        val title = TextView(this).apply { text = "8 BALL POOL\nASSISTANT PRO"; setTextColor(cyan); textSize = 25f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; setPadding(0, 4, 0, 4) }
        root.addView(title)
        val subtitle = TextView(this).apply { text = "ASISTENTE DE PRÁCTICA"; setTextColor(green); textSize = 12f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 14) }
        root.addView(subtitle)
        diagram = TableView().apply { layoutParams = LinearLayout.LayoutParams(-1, 220); }
        root.addView(diagram)
        angleText = label("Ángulo del tiro: 45°")
        root.addView(angleText)
        root.addView(seek(0, 90, angle) { angle = it; angleText.text = "Ángulo del tiro: ${angle}°"; diagram.invalidate() })
        powerText = label("Potencia: 60%")
        root.addView(powerText)
        root.addView(seek(1, 100, power) { power = it; powerText.text = "Potencia: ${power}%" })
        root.addView(label("Rebotes de referencia"))
        val choices = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL; setPadding(0, 0, 0, 8) }
        listOf("0", "1", "2").forEachIndexed { index, s ->
            val rb = RadioButton(this).apply { text = s; textSize = 15f; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(cyan); id = View.generateViewId() }
            choices.addView(rb); if (index == 1) rb.isChecked = true
        }
        choices.setOnCheckedChangeListener { group, checked -> bounces = group.indexOfChild(group.findViewById(checked)); bounceText.text = "Rebotes seleccionados: $bounces"; diagram.invalidate() }
        root.addView(choices)
        bounceText = label("Rebotes seleccionados: 1")
        root.addView(bounceText)
        val note = TextView(this).apply { text = "Herramienta independiente para practicar. No se conecta ni modifica 8 Ball Pool. La trayectoria real puede variar por efecto y colisión."; setTextColor(Color.LTGRAY); textSize = 12f; setPadding(12, 14, 12, 0); gravity = Gravity.CENTER }
        root.addView(note)
        val reset = Button(this).apply { text = "RESTABLECER"; setTextColor(Color.BLACK); setBackgroundColor(cyan); setOnClickListener { angle = 45; power = 60; bounces = 1; angleText.text = "Ángulo del tiro: 45°"; powerText.text = "Potencia: 60%"; bounceText.text = "Rebotes seleccionados: 1"; diagram.invalidate() } }
        root.addView(reset)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun label(textValue: String) = TextView(this).apply { text = textValue; setTextColor(Color.WHITE); textSize = 16f; setPadding(4, 8, 4, 2) }
    private fun seek(min: Int, max: Int, initial: Int, change: (Int) -> Unit) = SeekBar(this).apply { this.max = max - min; progress = initial - min; progressTintList = android.content.res.ColorStateList.valueOf(cyan); thumbTintList = android.content.res.ColorStateList.valueOf(green); setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) = change(p + min); override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {} }) }

    inner class TableView : View(this@MainActivity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat(); val h = height.toFloat(); val l = 14f; val t = 12f; val r = w - 14f; val b = h - 12f
            p.color = Color.rgb(92, 54, 29); c.drawRoundRect(l, t, r, b, 18f, 18f, p)
            p.color = Color.rgb(13, 105, 73); c.drawRoundRect(l + 13, t + 13, r - 13, b - 13, 10f, 10f, p)
            p.color = Color.WHITE; p.style = Paint.Style.STROKE; p.strokeWidth = 2f; c.drawRoundRect(l + 13, t + 13, r - 13, b - 13, 10f, 10f, p); p.style = Paint.Style.FILL
            val cx = w * .34f; val cy = h * .56f; val targetX = w * .76f; val targetY = h * .35f
            p.color = Color.WHITE; c.drawCircle(cx, cy, 9f, p)
            p.color = Color.YELLOW; c.drawCircle(targetX, targetY, 9f, p)
            val rad = Math.toRadians(angle.toDouble()); val len = min(w, h) * .48f
            p.color = cyan; p.strokeWidth = 3f; p.style = Paint.Style.STROKE
            val path = Path(); path.moveTo(cx, cy); path.lineTo(cx + cos(rad).toFloat() * len, cy - sin(rad).toFloat() * len); c.drawPath(path, p)
            p.style = Paint.Style.FILL
            p.color = Color.WHITE; p.textSize = 11f; c.drawText("BLANCA", cx - 22, cy + 25, p); c.drawText("OBJETIVO", targetX - 26, targetY + 24, p)
        }
    }
}
